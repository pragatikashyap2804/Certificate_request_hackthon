from flask import Flask, render_template, request, redirect, url_for, session
import mysql.connector  # MySQL connector
import pandas as pd
app = Flask(__name__)
app.secret_key = 'myPa$$w0rd'

# Configure MySQL connection
db = mysql.connector.connect(
    host='localhost',  # XAMPP's MySQL host
    user='root',  # Your MySQL username
    password='krish@8126',  # Your MySQL password
    database='culture'  # Your MySQL database name
)

@app.route('/')
def home():
    return render_template('home.html')
@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')

        # Check if the username is already taken
        cursor = db.cursor()
        cursor.execute("SELECT * FROM users WHERE username = %s", (username,))
        user = cursor.fetchone()

        if user:
            return 'Username already exists'

        # Create a new user record (you should hash the password for security)
        cursor.execute("INSERT INTO users (username, password) VALUES (%s, %s)", (username, password))
        db.commit()
        cursor.close()

        return redirect(url_for('login'))

    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')

        # Authenticate the user
        cursor = db.cursor()
        cursor.execute("SELECT * FROM users WHERE username = %s AND password = %s", (username, password))
        user = cursor.fetchone()
        cursor.close()

        if user:
            session['username'] = username
            return redirect('/protected')

        return 'Invalid username or password'

    return render_template('login.html')

@app.route('/protected')
def protected():
    return render_template('protected.html')

@app.route('/user')
def user():
    return render_template('user.html')

@app.route('/saved')
def saved():
    return render_template('saved.html')

@app.route('/logout')
def logout():
    session.pop('username', None)
    return redirect(url_for('login'))
if __name__ == '__main__':
    app.run(debug=True)