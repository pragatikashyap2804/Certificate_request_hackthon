from flask import Flask, render_template, request, redirect, url_for, session
import mysql.connector  # MySQL connector
import pandas as pd
app = Flask(__name__)
app.secret_key = 'myPa$$w0rd'

# Configure MySQL connection
db = mysql.connector.connect(
    host='localhost',  # XAMPP's MySQL host
    user='root',  # Your MySQL username
    password='krish@8126',  # Your MySQL password
    database='culture'  # Your MySQL database name
)

@app.route('/')
def home():
    return render_template('home.html')

@app.route('/bussiness', methods=['GET', 'POST'])
def business():
    if request.method == 'POST':
        # Get the form data
        state = request.form.get('state')
        city = request.form.get('city')

        # Save the data to a CSV file
        data = {
            'State': [state],
            'City': [city]
        }
        df = pd.DataFrame(data)
        df.to_csv('business_input.csv', mode='a', header=False, index=False)

    return render_template('businessmandetials.html')

@app.route('/traveller', methods=['GET', 'POST'])
def traveller():
    return render_template('travelerdetails.html')

@app.route('/travelerdetails')  
def traveler_details():
    return render_template('suggestion.html')


@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')

        # Check if the username is already taken
        cursor = db.cursor()
        cursor.execute("SELECT * FROM users WHERE username = %s", (username,))
        user = cursor.fetchone()

        if user:
            return 'Username already exists'

        # Create a new user record (you should hash the password for security)
        cursor.execute("INSERT INTO users (username, password) VALUES (%s, %s)", (username, password))
        db.commit()
        cursor.close()

        return redirect(url_for('login'))

    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')

        # Authenticate the user
        cursor = db.cursor()
        cursor.execute("SELECT * FROM users WHERE username = %s AND password = %s", (username, password))
        user = cursor.fetchone()
        cursor.close()

        if user:
            session['username'] = username
            return redirect('/protected')

        return 'Invalid username or password'

    return render_template('login.html')

@app.route('/protected')
def protected():
    return render_template('protected.html')

@app.route('/saved')
def saved():
    return render_template('saved.html')

@app.route('/logout')
def logout():
    session.pop('username', None)
    return redirect(url_for('login'))

if __name__ == '__main__':
    app.run(debug=True)
    @app.route('/submitbusinessman', methods=['GET', 'POST'])
    def submit_businessman():
        if request.method == 'POST':
            # Get the form data
            first_name = request.form.get('first_name')
            last_name = request.form.get('last_name')
            mobile = request.form.get('mobile')
            email = request.form.get('mail')
            aadhar = request.form.get('aadhar')
            aadhar_img = request.files.get('img')  # Use request.files to access uploaded files
            pan = request.form.get('pan')
            address = request.form.get('addr')
            document = request.files.get('doc')

            # Perform validation and data storage logic here
            # Ensure you validate the data and sanitize it as needed
            # For example, check if required fields are not empty, validate email format, and so on

            # Store the uploaded AADHAR image and documents in your desired directory
            if aadhar_img:
                aadhar_img.save('path_to_aadhar_uploads/' + aadhar_img.filename)
            if document:
                document.save('path_to_document_uploads/' + document.filename)

            # After processing the data, you can redirect to a success page or perform any other actions
            

        return render_template('/success')
    
@app.route('/success')
def psuccess():
    return render_template('success.html')

@app.route('/submittraveler', methods=['GET', 'POST'])
def submit_Traveler():
    if request.method == 'POST':
       # Get the form data
            first_name = request.form.get('first_name')
            last_name = request.form.get('last_name')
            mobile = request.form.get('mobile')
            email = request.form.get('mail')
            aadhar = request.form.get('aadhar')
            aadhar_img = request.files.get('img')  # Use request.files to access uploaded files
            pan = request.form.get('pan')
            address = request.form.get('addr')

            # Perform validation and data storage logic here
            # Ensure you validate the data and sanitize it as needed
            # For example, check if required fields are not empty, validate email format, and so on

            # Store the uploaded AADHAR image and documents in your desired directory
            
            # Authenticate the user
            # Check if the username is already taken
    return render_template('submit_Traveler.html')

@app.route('/success')
def psuccess_view():
     return render_template('success.html')